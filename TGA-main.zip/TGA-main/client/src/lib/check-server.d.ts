// c:/Users/aaaar/OneDrive/Desktop/LAST AND FINAL/TGA/client/src/lib/check-server.d.ts
declare module '@/lib/check-server' {
  export function checkServerAndShowError(): Promise<boolean>;
}